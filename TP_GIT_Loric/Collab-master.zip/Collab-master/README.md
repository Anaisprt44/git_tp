# Mon Projet

Bienvenue dans mon projet ! Cette version inclut une nouvelle fonctionnalité qui vous permet d'écrire en bleu.

## utilisation

Pour utiliser la nouvelle fonctionnalité, ajoutez la classe CSS "bleu" à votre élément HTML. Voici un exemple :

   html
<div class="bleu">
   <p>Ceci à un fond bleu.</p>
</div> 
